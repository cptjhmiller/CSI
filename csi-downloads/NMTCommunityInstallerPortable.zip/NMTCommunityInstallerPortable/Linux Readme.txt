Dear CSI user,

Thank you for downloading NMT Community Software Installer.
Before you can use this application make sure you have installed the following applications:
- Mono
- libmono-winforms

Add execute permissions on the "Linux Start.sh" and double click "Linux Start.sh" to start CSI.

Note: on some linux configurations CSI will not restart but close after selecting an interface language.
If this happens on your computer: just start CSI manually again and you should be fine.

Best regards,
Ger Teunis


----

Cher(e) utilisateur(trice) de CSI.

Merci d'avoir t�l�charg� NMT Community Software Installer.
Avant de pouvoir utiliser cette application, v�rifiez que vous avez install�
les applications suivantes:
- Mono 
- libmono-winforms

Ajoutez les permissions d'ex�cution sur le fichier "Linux Start.sh" et double cliquez
sur "Linux Start.sh" pour d�marrer CSI.

Note: sur certaines configurations Linux CSI ne d�marrera pas mais se
fermera apr�s la s�lection du langage. Dans ce cas: juste d�marrer CSI manuellement
de nouveau et ca devrait fonctionner.

Cordialement,
Ger Teunis