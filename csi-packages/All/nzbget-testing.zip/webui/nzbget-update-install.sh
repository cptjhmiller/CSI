#!/bin/sh
#MainDirName=.nzb
mkdir -p /tmp/nzbget
cd /tmp/nzbget
#echo "tar -zxf nzbget.$NZBUP_BRANCH.tar.gz -C /nmt/apps/"
#echo "$NZBOP_APPBIN -c $NZBOP_CONFIGFILE -D"
echo "Installing ${NZBUP_BRANCH}"
echo "Downloading new version...";
wget -q "http://78.46.108.209:8100/nzbget/nzbget.${NZBUP_BRANCH}.tar.gz"
#sleep 100
if [ -f "/tmp/nzbget/nzbget.${NZBUP_BRANCH}.tar.gz" ]; then
	echo "Downloaded new version...OK"
	#tar -zxvf nzbget.tar.gz -C /nmt/apps/
	tar -zxf nzbget.$NZBUP_BRANCH.tar.gz -C /nmt/apps/
	sleep 2        
	rm -R /tmp/nzbget
else        
	rm -R /tmp/nzbget
	echo "[ERROR] Download failed, try again later"
	sleep 10
	exit 0
fi
#echo "Stoping NZBGet Daemon : ";
echo -n "Stoping NZBGet Daemon : "
TEST=`pidof nzbget-update-install.sh`
kill `pidof -o $TEST nzbget`
sleep 2
echo "Starting NZBGet..."
$NZBOP_APPBIN -c $NZBOP_CONFIGFILE -D
#tar -czf name_of_your_archive.tar.gz -c bin/ webui/
