#!/bin/sh
#
mkdir -p /tmp/nzbget
cd /tmp/nzbget
echo "Installing ${NZBUP_BRANCH}"
echo "Downloading new version...";
wget -q "http://78.46.108.209:8100/nzbget/nzbget.${NZBUP_BRANCH}.tar.gz"

if [ -f "/tmp/nzbget/nzbget.${NZBUP_BRANCH}.tar.gz" ]; then
	echo "Downloaded new version...OK"
	tar -zxf nzbget.$NZBUP_BRANCH.tar.gz -C /nmt/apps/
	sleep 2        
	rm -R /tmp/nzbget
else        
	rm -R /tmp/nzbget
	echo "[ERROR] Download failed, try again later"
	sleep 10
	exit 0
fi
#Stop NZBGet Daemon
echo -n "Stoping NZBGet Daemon : "
kill `pidof nzbget`
sleep 2
echo "Starting NZBGet..."
$NZBOP_APPBIN -c $NZBOP_CONFIGFILE -D
