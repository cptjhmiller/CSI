#!/bin/sh 
# Param $1 -> Path to file
# Param $2 -> Filename of first file in torrent
DownloadDir="$1" 
log="$DownloadDir"/"$2".log  

cd "$DownloadDir" 
/nmt/apps/bin/unrar x -y -p- -o+ "$2" >> $log 
chmod -R a+rw . 
