#!/bin/sh
#
# Pure FTP Server
#

BINPATH="/nmt/apps/bin"
export_path="/tmp/ftp_share"

eexport_path() {
	share_path="/opt/sybhttpd/localhost.drives"
	file="/tmp/usb_name.txt"
	
	mkdir -p "$export_path"
	
	share=`ls -la / | grep -w -e "^l.* share" | awk '{ print $11}'`
	if [ -n "$share" ]; then
		length=${#share}
		echo "share = $share"
		echo "length = $length"
		echo
		echo
	
		#echo "qwe = ${asd:41:1}"
		if [ $length -gt 10 ]; then
			for ((i=0; i<2; i++))
			do
				length=$(($length-1))
				if [ ${share:$length:1} = "/" ]; then
					share=${share:0:$length}
				else
					break
				fi
			done
		fi
	
		echo "share = $share"
		echo "length = $length"
		echo "ABS = $export_path/share"
		if [ ! -e "$export_path/share" ]; then	# kswong remark, need to check
			ln -s "$share" "$export_path/share"
		fi
		echo
		echo
	fi
	
	val=0
	while :
	do
		val=$(($val+1))
		string=`cat $file | cut -d$'\xa' -f$val`
		if [ -n "$string" ]; then
			echo "string = $string"
	
			directory=`echo $string | cut -d\| -f1`
			name=`echo $string | cut -d\| -f2`
			if [ -n "$directory" -a -n "$name" ]; then
				echo "directory = $directory"
				echo "name = $name"
				echo "ABS = $export_path/$name"
				if [ ! -e "$export_path/$name" ]; then	# kswong remark, need to check
					ln -s "$share_path/$directory" "$export_path/$name"
				fi
				echo
				echo
			fi
		else
			break
		fi
	done
}

start() {
	echo -n "Starting FTP Server..."
	rm -rf "$export_path"	# wong new
	eexport_path			# wong new
	$BINPATH/nmt_services.cgi cmd=ftp_passwd opt=ftpuser > /dev/null 2> /dev/null
	$BINPATH/pure-ftpd -j -H --fscharset=utf-8 -lpuredb:/etc/pureftpd.pdb -U 133:022 -c 3 -C 3 -k 100 -I 1440 -w -B
}

stop() {
	echo -n "Stopping FTP Server..."
	killall pure-ftpd
	rm -rf "$export_path"	# wong new
}

restart() {
	stop
	start
}

case "$1" in
  start)
  	start
	;;
  stop)
  	stop
	;;
  restart|reload)
  	restart
	;;
  *)
	echo $"Usage: $0 {start|stop|restart}"
	exit 1
esac

exit $?

