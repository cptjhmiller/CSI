#!/bin/sh
#
# Samba
#

BINPATH="/nmt/apps/bin"

start() {
	if [ -e $BINPATH/nmt_services.cgi ]; then
		echo Updating samba config ...
		$BINPATH/nmt_services.cgi cmd=smb_boot > /dev/null 2> /dev/null
	fi
	
	passwd
	  
	if [ -e $BINPATH/smbd ]; then
		echo "Starting samba"
		killall nmbd
		nmbd -D &
		$BINPATH/smbd -D
	fi
}
	
stop() {
	echo "Stopping samba..."
	killall nmbd > /dev/null 2> /dev/null
	killall smbd > /dev/null 2> /dev/null
	rm -r /etc/samba/private > /dev/null 2> /dev/null
	rm -r /etc/samba/var > /dev/null 2> /dev/null
	mkdir -p /etc/samba/private > /dev/null 2> /dev/null
	mkdir -p /etc/samba/var/locks > /dev/null 2> /dev/null
}

passwd() {
	if [ -e $BINPATH/smbpasswd ]; then
		if [ -e $BINPATH/nmt_services.cgi ]; then
			echo "Updating samba password..."	
			$BINPATH/nmt_services.cgi cmd=smb_passwd > /dev/null 2> /dev/null	
		fi
	fi
}

restart() {
	stop
	start
}	

case "$1" in
  start)
  	start
	;;
  stop)
  	stop
	;;
  passwd)
	passwd
	;;
  restart|reload)
  	restart
	;;
  *)
	echo $"Usage: $0 {start|stop|passwd|restart}"
	exit 1
esac

exit $?

