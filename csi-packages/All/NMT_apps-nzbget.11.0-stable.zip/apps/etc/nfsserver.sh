#!/bin/sh
#
# Start/Stop NFS Server daemons
#

BINPATH="/nmt/apps/bin"
APPBINPATH="/nmt/apps/nfsserver"	
start()
{
	echo "Generate NFS shares export file..."
	$BINPATH/nmt_services.cgi cmd=nfs_share
	
	if test ! -d /var/lib/nfs 
 	 then
		mkdir -p /var/lib/nfs
	fi
	
	touch /var/lib/nfs/etab	> /dev/null 2> /dev/null
  	touch /var/lib/nfs/rmtab > /dev/null 2> /dev/null
  	touch /var/lib/nfs/xtab	> /dev/null 2> /dev/null
	
	ln -s $APPBINPATH/portmap	/usr/sbin/portmap
	ln -s $APPBINPATH/mountd	/usr/sbin/mountd
	ln -s $APPBINPATH/exportfs	/usr/sbin/exportfs
	ln -s $APPBINPATH/nfsd 		/usr/sbin/nfsd
	ln -s $APPBINPATH/statd 	/usr/sbin/statd
	ln -s $APPBINPATH/mount.nfs 	/sbin/mount.nfs
	
	echo "Starting RPC portmapper..."
	/usr/sbin/portmap	> /dev/null 2> /dev/null
	
	/usr/sbin/exportfs -r	> /dev/null 2> /dev/null
	
	 echo "Starting NFS services... "
	/usr/sbin/nfsd	> /dev/null 2> /dev/null
	
	echo  "Starting NFS mount services... "
	/usr/sbin/mountd	> /dev/null 2> /dev/null
	
	/usr/sbin/statd	> /dev/null 2> /dev/null
}

reload()
{
	echo "Re-export the NFS shares..."
	$BINPATH/nmt_services.cgi cmd=nfs_share > /dev/null 2> /dev/null
	/usr/sbin/exportfs -r > /dev/null 2> /dev/null
	touch /var/lib/nfs/etab > /dev/null 2> /dev/null
  	touch /var/lib/nfs/rmtab > /dev/null 2> /dev/null
  	touch /var/lib/nfs/xtab > /dev/null 2> /dev/null
}   

stop() 
{
	killall lockd
	kill `cat /tmp/rpc.statd.pid` 

	echo "Stopping NFS daemon... "
	killall -HUP nfsd

	echo "Stopping NFS mountd service... "
	killall mountd
	
	echo "Shutting down NFS services... "
	/usr/sbin/exportfs -au > /dev/null 2> /dev/null
	rm -r /var/lib/nfs > /dev/null 2> /dev/null
	
	echo "Stopping RPC Portmapper... "
	killall portmap 
}

restart() {
	stop
	start
}	

case "$1" in
  start)
  	start
	;;
  stop)
  	stop
	;;
  restart)
  	restart
  	;;
  reload)
  	reload
	;;
  *)
	echo $"Usage: $0 {start|stop|restart|reload}"
	exit 1
esac

exit $?

